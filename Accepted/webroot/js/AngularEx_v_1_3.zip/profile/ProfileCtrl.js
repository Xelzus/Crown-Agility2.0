app.controller("profileCtrl", function ($scope, $filter, $http, profileSvc) {
    //Data to be used on the web page using the controller
    $scope.model = {
        reminders: [],
        newReminder: {
            title: '',
            description: '',
            remindOn: ''
        }
    };

    //Functions
    //Ex: $scope.loadReminders = function() {
    //      ...code that loads reminders
    //    }
    $scope.loadReminders = function() {
        profileSvc.loadReminders()
        .success(function(data) {
            $scope.model.reminders = data.reminders;
        });
    };

    $scope.updateReminders = function() {
        $scope.loadReminders();
    };

    $scope.addReminder = function() {
        $scope.model.reminders.push({
            title: $scope.model.newReminder.title ,
            description: $scope.model.newReminder.description,
            remindOn: $filter('date')($scope.model.newReminder.remindOn, "MM/dd/yyyy hh:mm a")
        });

        $scope.model.newReminder.title = "";
        $scope.model.newReminder.description = "";
        $scope.model.newReminder.remindOn = "";

        updateReminders();
    };

    $scope.deleteReminder = function(id) {
        $scope.model.reminders.splice(id, 1);
    };

    //Initial call to loadReminders from DB
    $scope.loadReminders();
});
