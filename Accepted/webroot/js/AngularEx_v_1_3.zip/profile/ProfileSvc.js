'use strict';

app.factory('profileSvc', function ($http) {
    return {
        loadReminders: function() {
            return $http.get('Profiles/GetReminders', {
                headers:
                {
                  'Content-Type' : 'application/json; charset=utf-8',
                  'Accept' : 'application/json'
                }
            });
        }
    }
});
